import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import itertools
import warnings
warnings.filterwarnings("ignore") # Ignore warnings

#Premier League
pl_data = pd.read_csv('PL.csv', header=1)
pl_data['Week'] = pd.to_datetime(pl_data['Week'])
pl_data.set_index('Week', inplace=True)
pl_data = pl_data.asfreq('W')
pl_target_series = pl_data['Premier League: (United States)']

pl_mod = sm.tsa.statespace.SARIMAX(pl_target_series,
                                order=(1, 1, 1),
                                seasonal_order=(1, 1, 1, 52),
                                enforce_stationarity=False,
                                enforce_invertibility=False)

pl_results = pl_mod.fit()

pl_pred_uc = pl_results.get_forecast(steps=200)
pl_pred_ci = pl_pred_uc.conf_int()

#La Liga
ll_data = pd.read_csv('LaLiga.csv', header=1)
ll_data['Week'] = pd.to_datetime(ll_data['Week'])
ll_data.set_index('Week', inplace=True)
ll_data = ll_data.asfreq('W')
ll_target_series = ll_data['LaLiga: (United States)']

ll_mod = sm.tsa.statespace.SARIMAX(ll_target_series,
                                order=(1, 0, 1),
                                seasonal_order=(0, 1, 1, 52),
                                enforce_stationarity=False,
                                enforce_invertibility=False)

ll_results = ll_mod.fit()

ll_pred_uc = ll_results.get_forecast(steps=200)
ll_pred_ci = ll_pred_uc.conf_int()

#Bundesliga
bl_data = pd.read_csv('Bundesliga.csv', header=1)
bl_data['Week'] = pd.to_datetime(bl_data['Week'])
bl_data.set_index('Week', inplace=True)
bl_data = bl_data.asfreq('W')
bl_target_series = bl_data['Bundesliga: (United States)']

bl_mod = sm.tsa.statespace.SARIMAX(bl_target_series,
                                order=(1, 1, 1),
                                seasonal_order=(1, 1, 1, 52),
                                enforce_stationarity=False,
                                enforce_invertibility=False)

bl_results = bl_mod.fit()

bl_pred_uc = bl_results.get_forecast(steps=200)
bl_pred_ci = bl_pred_uc.conf_int()

#Serie A
sa_data = pd.read_csv('SerieA.csv', header=1)
sa_data['Week'] = pd.to_datetime(sa_data['Week'])
sa_data.set_index('Week', inplace=True)
sa_data = sa_data.asfreq('W')
sa_target_series = sa_data['Serie A: (United States)']

sa_mod = sm.tsa.statespace.SARIMAX(sa_target_series,
                                order=(1, 1, 1),
                                seasonal_order=(1, 1, 1, 52),
                                enforce_stationarity=False,
                                enforce_invertibility=False)

sa_results = sa_mod.fit()
sa_pred_uc = sa_results.get_forecast(steps=200)
sa_pred_ci = sa_pred_uc.conf_int()

#MLS
ml_data = pd.read_csv('MLS.csv', header=1)
ml_data['Week'] = pd.to_datetime(ml_data['Week'])
ml_data.set_index('Week', inplace=True)
ml_data = ml_data.asfreq('W')
ml_target_series = ml_data['MLS: (United States)']

ml_mod = sm.tsa.statespace.SARIMAX(ml_target_series,
                                order=(1, 1, 1),
                                seasonal_order=(0, 1, 1, 52),
                                enforce_stationarity=False,
                                enforce_invertibility=False)

ml_results = ml_mod.fit()
ml_pred_uc = ml_results.get_forecast(steps=200)
ml_pred_ci = ml_pred_uc.conf_int()

#Ligue 1
lu_data = pd.read_csv('Ligue1.csv', header=1)
lu_data['Week'] = pd.to_datetime(lu_data['Week'])
lu_data.set_index('Week', inplace=True)
lu_data = lu_data.asfreq('W')
lu_target_series = lu_data['Ligue 1: (United States)']

lu_mod = sm.tsa.statespace.SARIMAX(lu_target_series,
                                order=(1, 1, 1),
                                seasonal_order=(0, 1, 1, 52),
                                enforce_stationarity=False,
                                enforce_invertibility=False)

lu_results = lu_mod.fit()
lu_pred_uc = lu_results.get_forecast(steps=200)
lu_pred_ci = lu_pred_uc.conf_int()

plt.figure(figsize=(20, 15))
# Premier League Observed and Forecast
pl_pred_uc.predicted_mean.plot(label='Premier League Forecast', color='Blue')

# La Liga Observed and Forecast
ll_pred_uc.predicted_mean.plot(label='La Liga Forecast', color='Red')

# Bundesliga Observed and Forecast
bl_pred_uc.predicted_mean.plot(label='Bundesliga Forecast', color='saddlebrown')

# Serie A Observed and Forecast
sa_pred_uc.predicted_mean.plot(label='Serie A Forecast', color='green')

# MLS Observed and Forecast
ml_pred_uc.predicted_mean.plot(label='MLS Forecast', color='yellow')

# Ligue 1 Observed and Forecast
lu_pred_uc.predicted_mean.plot(label='Ligue 1 Forecast', color='purple')

# Customize Plot
plt.xlabel('Date')
plt.ylabel('Volume')
plt.title('Popularity Forecasts')
plt.legend()
plt.show()
