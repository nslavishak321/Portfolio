import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import itertools
import warnings
warnings.filterwarnings("ignore") # Ignore warnings

data = pd.read_csv('SerieA.csv', header=1)
data['Week'] = pd.to_datetime(data['Week'])
data.set_index('Week', inplace=True)
data = data.asfreq('W')
target_series = data['Serie A: (United States)']

mod = sm.tsa.statespace.SARIMAX(target_series,
                                order=(1, 1, 1),
                                seasonal_order=(1, 1, 1, 52),
                                enforce_stationarity=False,
                                enforce_invertibility=False)

results = mod.fit()

start_date = '2023-11-26'
end_date = '2024-11-10'

pred = results.get_prediction(start=pd.to_datetime(start_date), end=pd.to_datetime(end_date), dynamic=False, full_results=True)
pred_ci = pred.conf_int()

ax = data['2019-11-10':].plot(label='observed')
pred.predicted_mean.plot(ax=ax, label='Forecast')

ax.fill_between(pred_ci.index,
                pred_ci.iloc[:, 0],
                pred_ci.iloc[:, 1], color='k', alpha=.25)

ax.fill_betweenx(ax.get_ylim(), pd.to_datetime(start_date), data.index[-1],alpha=.1, zorder=-1)

ax.set_xlabel('Date')
ax.set_ylabel('Volume')
plt.legend()
plt.show()

pred_uc = results.get_forecast(steps=200)
pred_ci = pred_uc.conf_int()

ax = data.plot(label='Observed', figsize=(20, 15))
pred_uc.predicted_mean.plot(ax=ax, label='Forecast')
ax.fill_between(pred_ci.index,
                pred_ci.iloc[:, 0],
                pred_ci.iloc[:, 1], color='k', alpha=.25)
ax.set_xlabel('Date')
ax.set_ylabel('Volume')

plt.legend()
plt.show()